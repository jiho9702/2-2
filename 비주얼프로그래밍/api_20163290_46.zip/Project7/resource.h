//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Project7.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDR_MENU1                       101
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003
#define ID_40004                        40004
#define ID_40005                        40005
#define ID_LINE                         40006
#define ID_ELLIPSE                      40007
#define ID_RECTANGLE                    40008
#define ID_PENCOLOR                     40009
#define ID_FACECOLOR                    40010
#define LINE                            40011
#define ELLIPSE                         40012
#define RECTANGLE                       40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
